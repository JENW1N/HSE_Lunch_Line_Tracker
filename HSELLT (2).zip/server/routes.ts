import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import { analyzeLunchLineImage } from "./utils/openai";

const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (_req: Express.Request, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
    const allowedTypes = ["image/jpeg", "image/png", "image/jpg", "image/heic"];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error(`Invalid file type: ${file.mimetype}. Only jpg, jpeg, png and heic allowed.`));
    }
  },
});

const LINE_MULTIPLIERS: Record<string, number> = {
  cca: 1.25,
  chicken: 1.1,
  deli: 0.9,
  homecooking: 0.85,
  international: 0.8,
  pizza: 1.2,
  royalcafe: 1.05,
  royalgarden: 0.95
};

export function registerRoutes(app: Express): Server {
  app.post("/api/analyze", upload.single("image"), async (req: Request, res) => {
    const file = req.file;
    const selectedLine = req.body.line;

    if (!file) {
      return res.status(400).json({ message: "No image provided" });
    }

    try {
      // Use OpenAI to analyze the image
      const analysis = await analyzeLunchLineImage(file.buffer);

      // Size-based time for food collection (in seconds)
      const sizeBaseTimes = {
        S: 30,  // Small students
        M: 35,  // Medium students
        L: 40,  // Large students
        XL: 42, // Extra large students
        XXL: 45 // Extra extra large students
      };

      // Calculate total wait time
      let totalWaitTime = 0;
      let totalStudents = 0;

      Object.entries(analysis.sizeCounts).forEach(([size, count]) => {
        const baseTime = sizeBaseTimes[size as keyof typeof sizeBaseTimes];
        // For each person: base time + typing (10s) + movement (3s)
        totalWaitTime += count * (baseTime + 10 + 3);
        totalStudents += count;
      });

      // Apply line-specific multiplier
      const lineMultiplier = LINE_MULTIPLIERS[selectedLine] || 1;
      totalWaitTime *= lineMultiplier;

      // Divide total time by 2 to account for parallel processing
      totalWaitTime /= 2;

      // Apply the 1.34x multiplier as requested
      totalWaitTime *= 1.34;

      // If there are more than 7 students, divide by 1.3 to account for increased efficiency
      if (totalStudents > 7) {
        totalWaitTime /= 1.3;
      }

      // Divide by 1.66 as requested
      totalWaitTime /= 1.66;

      // Convert to minutes and round to nearest half minute
      const waitTimeMinutes = Math.ceil((totalWaitTime / 60) * 2) / 2;

      res.json({
        waitTime: waitTimeMinutes,
        count: totalStudents,
        sizeCounts: analysis.sizeCounts
      });
    } catch (error) {
      console.error('Error processing image:', error);
      res.status(500).json({ message: "Failed to analyze image" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}