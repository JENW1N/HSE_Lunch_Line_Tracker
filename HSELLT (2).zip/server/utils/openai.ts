import OpenAI from "openai";

if (!process.env.OPENAI_API_KEY) {
  throw new Error("Missing OPENAI_API_KEY environment variable");
}

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function analyzeLunchLineImage(imageBuffer: Buffer): Promise<{
  studentCount: number;
  queueLength: number;
  confidence: number;
  sizeCounts: {
    S: number;
    M: number;
    L: number;
    XL: number;
    XXL: number;
  };
}> {
  try {
    const base64Image = imageBuffer.toString('base64');

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert at analyzing lunch line images and assessing student physical characteristics. Analyze students' relative sizes, with larger students categorized in higher size categories (XL, XXL) and slimmer students in lower categories (S, M). Every student must be assigned to a size category. Be thorough in your size distribution analysis."
        },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Analyze this lunch line image and provide: 1) Total number of students 2) Queue length in meters 3) Confidence level (0-1) 4) Size distribution of ALL students (S/M/L/XL/XXL). Larger students should be in XL/XXL categories, average in M/L, and slimmer in S. EVERY student must be categorized. Return JSON format with these exact keys: student_count, queue_length, confidence, size_distribution"
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${base64Image}`
              }
            }
          ],
        },
      ],
      response_format: { type: "json_object" }
    });

    const content = response.choices[0].message.content || '{"student_count": 0, "queue_length": 0, "confidence": 0, "size_distribution": {"S": 0, "M": 0, "L": 0, "XL": 0, "XXL": 0}}';
    const result = JSON.parse(content);

    // Ensure the total of size distribution matches student count
    const totalFromSizes = Object.values(result.size_distribution || {}).reduce((a, b) => a + b, 0);
    if (totalFromSizes !== result.student_count) {
      // Adjust M size count to match total if needed
      result.size_distribution.M += (result.student_count - totalFromSizes);
    }

    return {
      studentCount: Math.max(1, Math.round(result.student_count)),
      queueLength: Math.max(0.5, Number(result.queue_length)),
      confidence: Math.max(0, Math.min(1, Number(result.confidence))),
      sizeCounts: {
        S: result.size_distribution?.S || 0,
        M: result.size_distribution?.M || 0,
        L: result.size_distribution?.L || 0,
        XL: result.size_distribution?.XL || 0,
        XXL: result.size_distribution?.XXL || 0,
      }
    };
  } catch (error) {
    console.error('Error analyzing image:', error);
    // Return default values if analysis fails
    return {
      studentCount: 1,
      queueLength: 1,
      confidence: 0.5,
      sizeCounts: {
        S: 0,
        M: 1,
        L: 0,
        XL: 0,
        XXL: 0
      }
    };
  }
}