import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import ImageUpload from "@/components/ImageUpload";
import LoadingScreen from "@/components/LoadingScreen";
import Results from "@/components/Results";
import MenuOptions from "@/components/MenuOptions";
import OnboardingTutorial from "@/components/OnboardingTutorial";
import AnimatedClock from "@/components/AnimatedClock";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Clock, Users, Camera } from "lucide-react";

type AnalysisState = "upload" | "menu" | "loading" | "results";

export default function Home() {
  const [state, setState] = useState<AnalysisState>("upload");
  const [image, setImage] = useState<File | null>(null);
  const [menuData, setMenuData] = useState<string[]>([]);
  const { toast } = useToast();
  const [results, setResults] = useState<{ waitTime: number; count: number; sizeCounts: Record<string, number> } | null>(null);

  const analysisMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const res = await fetch("/api/analyze", {
        method: "POST",
        body: formData,
      });
      if (!res.ok) {
        const error = await res.text();
        throw new Error(error);
      }
      return res.json();
    },
    onSuccess: (data) => {
      setResults(data);
      setState("results");
    },
    onError: (error: Error) => {
      toast({
        title: "Error analyzing image",
        description: error.message,
        variant: "destructive",
      });
      setState("upload");
    },
  });

  const handleImageUpload = (file: File) => {
    setImage(file);
    setState("menu");
  };

  const handleMenuSubmit = (line: string) => {
    setState("loading");
    const formData = new FormData();
    if (image) {
      formData.append("image", image);
    }
    formData.append("line", line);
    analysisMutation.mutate(formData);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800">
      <OnboardingTutorial />

      {/* Navigation Bar */}
      <nav className="bg-slate-800/50 shadow-lg border-b border-slate-700 px-4 py-3 mb-4 sm:mb-8 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AnimatedClock />
            <span className="text-lg sm:text-xl font-semibold text-slate-100">Wait Time Estimator</span>
          </div>
          <div className="flex gap-4">
            {state !== "upload" && state !== "results" && (
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => {
                  setImage(null);
                  setMenuData([]);
                  setResults(null);
                  setState("upload");
                }}
                className="text-sm sm:text-base text-blue-400 hover:text-blue-300 transition-colors"
              >
                Start Over
              </motion.button>
            )}
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-4 sm:py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl mx-auto"
        >
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="bg-slate-800/50 backdrop-blur-sm rounded-xl sm:rounded-2xl shadow-xl border border-slate-700 p-4 sm:p-8 mb-8"
          >
            <motion.h1 
              className="text-2xl sm:text-4xl font-bold text-center mb-2 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-400"
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 200 }}
            >
              Lunch Line Time Estimator
            </motion.h1>
            <motion.p 
              className="text-center text-sm sm:text-base text-slate-300 mb-6 sm:mb-8"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
              Upload a photo of your lunch line to get an estimated wait time
            </motion.p>

            <AnimatePresence mode="wait">
              {state === "upload" && (
                <motion.div 
                  data-tutorial="upload-area"
                  key="upload"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                >
                  <ImageUpload onUpload={handleImageUpload} />
                </motion.div>
              )}

              {state === "menu" && (
                <motion.div 
                  data-tutorial="menu-selection"
                  key="menu"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                >
                  <MenuOptions onSubmit={handleMenuSubmit} />
                </motion.div>
              )}

              {state === "loading" && (
                <motion.div
                  key="loading"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="min-h-[300px] sm:min-h-[400px]"
                >
                  <LoadingScreen 
                    menuItems={menuData}
                    sizeCounts={analysisMutation.data?.sizeCounts}
                  />
                </motion.div>
              )}

              {state === "results" && results && (
                <motion.div 
                  data-tutorial="results-area"
                  key="results"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                >
                  <Results 
                    waitTime={results.waitTime} 
                    count={results.count}
                    sizeCounts={results.sizeCounts}
                    onReset={() => {
                      setImage(null);
                      setMenuData([]);
                      setResults(null);
                      setState("upload");
                    }}
                  />
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}