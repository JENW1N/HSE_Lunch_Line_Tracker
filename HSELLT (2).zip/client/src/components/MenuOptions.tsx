import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";

interface LineOptionsProps {
  onSubmit: (line: string) => void;
}

const DINING_LINES = [
  { id: "cca", name: "CCA", multiplier: 1.25 },
  { id: "chicken", name: "Chicken Line", multiplier: 1.1 },
  { id: "deli", name: "Deli", multiplier: 0.9 },
  { id: "homecooking", name: "Home Cooking", multiplier: 0.85 },
  { id: "international", name: "International Fare", multiplier: 0.8 },
  { id: "pizza", name: "Pizza", multiplier: 1.2 },
  { id: "royalcafe", name: "Royal Café", multiplier: 1.05 },
  { id: "royalgarden", name: "Royal Garden", multiplier: 0.95 }
];

export default function LineOptions({ onSubmit }: LineOptionsProps) {
  const [selectedLine, setSelectedLine] = useState<string>("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedLine) {
      onSubmit(selectedLine);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
    >
      <Card className="p-6 bg-slate-800/50 border-slate-700">
        <h2 className="text-2xl font-bold text-blue-400 mb-4">
          Which dining line are you checking? 🍽️
        </h2>

        <form onSubmit={handleSubmit} className="space-y-6">
          <RadioGroup
            value={selectedLine}
            onValueChange={setSelectedLine}
            className="grid gap-4"
          >
            {DINING_LINES.map((line) => (
              <div key={line.id} className="flex items-center space-x-2">
                <RadioGroupItem value={line.id} id={line.id} />
                <Label htmlFor={line.id} className="text-lg text-slate-200 hover:text-slate-100">
                  {line.name}
                </Label>
              </div>
            ))}
          </RadioGroup>

          <Button
            type="submit"
            className="w-full bg-blue-500 hover:bg-blue-600 text-white"
            disabled={!selectedLine}
          >
            Calculate Wait Time
          </Button>
        </form>
      </Card>
    </motion.div>
  );
}