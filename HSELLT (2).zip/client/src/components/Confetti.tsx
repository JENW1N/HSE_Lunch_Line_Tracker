import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect } from "react";

interface Props {
  numberOfPieces?: number;
}

export default function Confetti({ numberOfPieces = 100 }: Props) {
  const [pieces, setPieces] = useState<Array<{
    x: number;
    delay: number;
    color: string;
    size: number;
    rotation: number;
    shape: "circle" | "square" | "triangle";
  }>>([]);

  const colors = [
    '#60A5FA', // Blue
    '#34D399', // Green
    '#F87171', // Red
    '#FBBF24', // Yellow
    '#A78BFA', // Purple
    '#EC4899', // Pink
    '#6EE7B7', // Teal
    '#FCD34D', // Amber
    '#F472B6', // Pink
    '#818CF8'  // Indigo
  ];

  const shapes = {
    circle: "circle(50% at 50% 50%)",
    square: "polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%)",
    triangle: "polygon(50% 0%, 100% 100%, 0% 100%)"
  };

  useEffect(() => {
    // Generate random confetti pieces
    const newPieces = Array.from({ length: numberOfPieces }).map(() => ({
      x: Math.random() * 100, // Random x position (0-100%)
      delay: Math.random() * 0.8, // Random delay (0-0.8s)
      color: colors[Math.floor(Math.random() * colors.length)],
      size: Math.random() * 10 + 5, // Random size between 5-15px
      rotation: Math.random() * 360, // Random initial rotation
      shape: ["circle", "square", "triangle"][Math.floor(Math.random() * 3)] as "circle" | "square" | "triangle"
    }));
    setPieces(newPieces);

    // Cleanup confetti after animation
    const timeout = setTimeout(() => {
      setPieces([]);
    }, 4000); // Clean up after all animations complete

    return () => clearTimeout(timeout);
  }, [numberOfPieces]);

  return (
    <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
      {pieces.map((piece, i) => (
        <motion.div
          key={i}
          initial={{
            x: `${piece.x}vw`,
            y: -20,
            scale: 1,
            rotate: piece.rotation,
            opacity: 1
          }}
          animate={{
            y: "100vh",
            scale: [1, 1.2, 0.8, 0.4, 0],
            rotate: piece.rotation + 360 * 2,
            opacity: [1, 1, 0.8, 0.4, 0]
          }}
          transition={{
            duration: 2.5 + Math.random() * 0.5,
            delay: piece.delay,
            ease: [0.23, 0.51, 0.32, 0.95],
            scale: {
              duration: 2.5,
              times: [0, 0.4, 0.7, 0.9, 1]
            },
            opacity: {
              duration: 2.5,
              times: [0, 0.4, 0.7, 0.9, 1]
            }
          }}
          style={{
            position: "absolute",
            top: 0,
            width: piece.size,
            height: piece.size,
            backgroundColor: piece.color,
            clipPath: shapes[piece.shape],
            willChange: "transform, opacity"
          }}
        />
      ))}
    </div>
  );
}