import { motion } from "framer-motion";
import { useCallback, useState } from "react";
import { useDropzone } from "react-dropzone";
import { Card } from "@/components/ui/card";
import { Image as ImageIcon, Upload } from "lucide-react";

interface ImageUploadProps {
  onUpload: (file: File) => void;
}

export default function ImageUpload({ onUpload }: ImageUploadProps) {
  const [preview, setPreview] = useState<string | null>(null);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      setPreview(URL.createObjectURL(file));
      onUpload(file);
    }
  }, [onUpload]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png']
    },
    maxFiles: 1
  });

  return (
    <motion.div
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
    >
      <Card
        {...getRootProps()}
        className={`
          h-[200px] sm:h-[300px] lg:h-[400px] flex flex-col items-center justify-center p-4 sm:p-8 cursor-pointer
          border-4 border-dashed transition-colors
          ${isDragActive ? 'border-blue-400 bg-slate-700' : 'border-slate-600 bg-slate-700/50'}
        `}
      >
        <input {...getInputProps()} />

        {preview ? (
          <motion.div
            className="relative w-full h-full flex items-center justify-center overflow-hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <motion.div
              className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-purple-500/10"
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              transition={{ delay: 0.2 }}
            />
            <motion.img
              src={preview}
              alt="Preview"
              className="relative z-10 max-h-full w-auto object-contain rounded-lg shadow-xl"
              initial={{ 
                scale: 1.5,
                opacity: 0,
                filter: "blur(10px) brightness(1.2)",
                y: 20
              }}
              animate={{ 
                scale: 1,
                opacity: 1,
                filter: "blur(0px) brightness(1)",
                y: 0
              }}
              transition={{
                duration: 0.6,
                ease: [0.23, 1, 0.32, 1]
              }}
            />
            <motion.div
              className="absolute inset-0 pointer-events-none"
              initial={{ opacity: 0, scale: 1.1 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4 }}
              style={{
                background: "radial-gradient(circle at center, transparent 30%, rgba(0,0,0,0.2) 100%)"
              }}
            />
          </motion.div>
        ) : (
          <motion.div
            className="text-center px-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            {isDragActive ? (
              <motion.div
                initial={{ scale: 1 }}
                animate={{
                  scale: [1, 1.05, 1],
                  filter: ["brightness(1)", "brightness(1.2)", "brightness(1)"]
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                <Upload className="w-12 h-12 sm:w-16 sm:h-16 mx-auto mb-4 text-blue-400" />
                <motion.div
                  className="absolute inset-0 bg-blue-400/10 rounded-full blur-xl"
                  animate={{
                    scale: [1, 1.2, 1],
                    opacity: [0.3, 0.5, 0.3]
                  }}
                  transition={{
                    duration: 1.5,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                />
              </motion.div>
            ) : (
              <motion.div
                whileHover={{ scale: 1.05 }}
                transition={{ type: "spring", stiffness: 400, damping: 25 }}
              >
                <ImageIcon className="w-12 h-12 sm:w-16 sm:h-16 mx-auto mb-4 text-slate-400" />
              </motion.div>
            )}
            <p className="text-base sm:text-lg font-medium text-slate-200">
              {isDragActive ? "Drop it like it's hot! 🔥" : "Drag & drop your lunch line photo"}
            </p>
            <p className="text-xs sm:text-sm text-slate-400 mt-2">
              or click to select
            </p>
          </motion.div>
        )}
      </Card>
    </motion.div>
  );
}