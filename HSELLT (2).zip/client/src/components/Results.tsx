import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Clock, Users, RotateCcw } from "lucide-react";
import Confetti from "./Confetti";

interface ResultsProps {
  waitTime: number;
  count: number;
  sizeCounts: Record<string, number>;
  onReset: () => void;
}

export default function Results({ waitTime, count, sizeCounts, onReset }: ResultsProps) {
  const formatTime = (minutes: number) => {
    if (minutes < 60) {
      return `${minutes} minutes`;
    }
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    return `${hours} hour${hours > 1 ? 's' : ''} ${remainingMinutes} minutes`;
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
    >
      <Confetti />
      <Card className="p-4 sm:p-8 bg-slate-800/50 border-slate-700">
        <motion.div
          initial={{ y: 20 }}
          animate={{ y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-center mb-6 sm:mb-8"
        >
          <h2 className="text-2xl sm:text-3xl font-bold text-blue-400 mb-2">
            Results Are In! 🎉
          </h2>
          <p className="text-sm sm:text-base text-slate-300">
            Here's what we found in your lunch line...
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6 mb-6 sm:mb-8">
          <motion.div
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="flex items-center gap-3 sm:gap-4 p-3 sm:p-4 bg-blue-500/10 rounded-lg border border-blue-500/20"
          >
            <Clock className="w-6 h-6 sm:w-8 sm:h-8 text-blue-400" />
            <div>
              <p className="text-xs sm:text-sm text-blue-300">Estimated Wait Time</p>
              <p className="text-xl sm:text-2xl font-bold text-blue-200">
                {formatTime(waitTime)}
              </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ x: 20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="flex items-center gap-3 sm:gap-4 p-3 sm:p-4 bg-slate-700/50 rounded-lg border border-slate-600"
          >
            <Users className="w-6 h-6 sm:w-8 sm:h-8 text-slate-300" />
            <div>
              <p className="text-xs sm:text-sm text-slate-400">Students in Line</p>
              <p className="text-xl sm:text-2xl font-bold text-slate-200">{count}</p>
            </div>
          </motion.div>
        </div>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="text-center"
        >
          <Button
            onClick={onReset}
            variant="outline"
            className="gap-2 border-slate-600 text-slate-300 hover:text-slate-200"
          >
            <RotateCcw className="w-4 h-4" />
            Try Another Line
          </Button>
        </motion.div>
      </Card>
    </motion.div>
  );
}