import { motion } from "framer-motion";

export default function AnimatedClock() {
  return (
    <div className="relative w-6 h-6">
      <svg
        viewBox="0 0 24 24"
        className="w-full h-full text-blue-400"
      >
        {/* Clock face */}
        <circle
          cx="12"
          cy="12"
          r="10"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.5"
          className="opacity-50"
        />

        {/* Hour hand */}
        <motion.line
          x1="12"
          y1="12"
          x2="12"
          y2="7"
          stroke="currentColor"
          strokeWidth="1.5"
          strokeLinecap="round"
          initial={{ rotate: 0 }}
          animate={{ rotate: 360 }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "linear",
          }}
          style={{ originX: "12px", originY: "12px" }}
        />

        {/* Minute hand */}
        <motion.line
          x1="12"
          y1="12"
          x2="12"
          y2="5"
          stroke="currentColor"
          strokeWidth="1"
          strokeLinecap="round"
          initial={{ rotate: 0 }}
          animate={{ rotate: 360 }}
          transition={{
            duration: 5,
            repeat: Infinity,
            ease: "linear",
          }}
          style={{ originX: "12px", originY: "12px" }}
        />

        {/* Center dot */}
        <circle
          cx="12"
          cy="12"
          r="1"
          fill="currentColor"
        />
      </svg>

      {/* Subtle glow effect */}
      <motion.div
        className="absolute inset-0 bg-blue-400/10 rounded-full blur-sm -z-10"
        animate={{
          scale: [0.8, 1, 0.8],
          opacity: [0.3, 0.5, 0.3],
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
    </div>
  );
}