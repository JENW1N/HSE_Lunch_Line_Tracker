import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from "@/components/ui/hover-card";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";

interface TutorialStep {
  target: string;
  title: string;
  content: string;
  position: "top" | "bottom" | "left" | "right";
}

const tutorialSteps: TutorialStep[] = [
  {
    target: "upload-area",
    title: "Upload Your Photo 📸",
    content: "Start by taking a photo of your lunch line. Drag and drop or click to select.",
    position: "bottom"
  },
  {
    target: "menu-selection",
    title: "Select Your Line 🍽️",
    content: "Choose which dining line you're in. Different lines have different wait times!",
    position: "right"
  },
  {
    target: "results-area",
    title: "Get Your Wait Time ⏰",
    content: "We'll analyze the crowd and tell you approximately how long you'll need to wait.",
    position: "left"
  }
];

export default function OnboardingTutorial() {
  const [isVisible, setIsVisible] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);

  useEffect(() => {
    const hasSeenTutorial = localStorage.getItem("hasSeenTutorial");
    if (!hasSeenTutorial) {
      setIsVisible(true);
    }
  }, []);

  const handleComplete = () => {
    localStorage.setItem("hasSeenTutorial", "true");
    setIsVisible(false);
  };

  const currentTutorialStep = tutorialSteps[currentStep];

  if (!isVisible) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center"
      >
        <div className="absolute inset-0 pointer-events-none" />

        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="bg-slate-800 rounded-lg shadow-xl p-6 max-w-md w-full mx-4 border border-slate-700"
        >
          <button
            onClick={handleComplete}
            className="absolute top-4 right-4 text-slate-400 hover:text-slate-300"
          >
            <X size={20} />
          </button>

          <div className="text-center mb-6">
            <h3 className="text-2xl font-bold text-blue-400 mb-2">
              Welcome to Wait Time Estimator! 👋
            </h3>
            <p className="text-slate-300">
              Let's show you how it works
            </p>
          </div>

          <div className="space-y-4 mb-6">
            {tutorialSteps.map((step, index) => (
              <div
                key={step.target}
                className={`p-4 rounded-lg transition-colors ${
                  currentStep === index
                    ? "bg-slate-700 border-2 border-blue-400/30"
                    : "bg-slate-800/50"
                }`}
              >
                <h4 className="font-semibold text-slate-200">{step.title}</h4>
                <p className="text-slate-400 text-sm">{step.content}</p>
              </div>
            ))}
          </div>

          <div className="flex justify-between">
            <Button
              variant="outline"
              onClick={() => setCurrentStep((prev) => Math.max(0, prev - 1))}
              disabled={currentStep === 0}
              className="border-slate-600 text-slate-300 hover:text-slate-200"
            >
              Previous
            </Button>

            {currentStep < tutorialSteps.length - 1 ? (
              <Button
                onClick={() => setCurrentStep((prev) => prev + 1)}
                className="bg-blue-500 hover:bg-blue-600 text-white"
              >
                Next
              </Button>
            ) : (
              <Button
                onClick={handleComplete}
                className="bg-blue-500 hover:bg-blue-600 text-white"
              >
                Get Started
              </Button>
            )}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}