import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect } from "react";

const generateLoadingMessages = (menuItems: string[] = [], sizeCounts?: Record<string, number>) => {
  const baseMessages = [
    "Calculating BMI distribution in queue... 📊",
    "Measuring average shoulder width per student... 📏",
    "Computing mass displacement in cafeteria space... ⚖️",
    "Analyzing spatial density of hunger indicators... 🔬",
    "Calibrating industrial-grade scales... ⚖️",
    "Measuring queue compression ratio... 📐",
    "Calculating mass-to-velocity ratios... 🎯"
  ];

  // Add size-specific messages if we have the data
  if (sizeCounts) {
    if (sizeCounts.XXL > 0) {
      baseMessages.push(
        `Mass exceeding measurement limits: ${sizeCounts.XXL} student${sizeCounts.XXL > 1 ? 's' : ''} detected... ⚠️`,
        `Recalibrating scales for ${sizeCounts.XXL} heavyweight contender${sizeCounts.XXL > 1 ? 's' : ''}... ⚖️`,
        `Industrial-grade scale required for ${sizeCounts.XXL} measurement${sizeCounts.XXL > 1 ? 's' : ''}... 🏋️‍♂️`
      );
    }
    if (sizeCounts.XL > 0) {
      baseMessages.push(
        `Computing displacement for ${sizeCounts.XL} above-average mass${sizeCounts.XL > 1 ? 'es' : ''}... 📊`,
        `Measuring substantial mass distribution: ${sizeCounts.XL} XL reading${sizeCounts.XL > 1 ? 's' : ''}... ⚖️`,
        `Calculating spatial requirements for ${sizeCounts.XL} larger specimen${sizeCounts.XL > 1 ? 's' : ''}... 📏`
      );
    }
    if (sizeCounts.S > 0) {
      baseMessages.push(
        `Detecting ${sizeCounts.S} lightweight measurement${sizeCounts.S > 1 ? 's' : ''} in dataset... 📉`,
        `Analyzing ${sizeCounts.S} below-average mass reading${sizeCounts.S > 1 ? 's' : ''}... 🔍`,
        `Small mass detected: ${sizeCounts.S} minimal impact measurement${sizeCounts.S > 1 ? 's' : ''}... ⚡`
      );
    }
  }

  return baseMessages;
};

interface Props {
  menuItems?: string[];
  sizeCounts?: Record<string, number>;
}

export default function LoadingScreen({ menuItems = [], sizeCounts }: Props) {
  const [messageIndex, setMessageIndex] = useState(0);
  const loadingMessages = generateLoadingMessages(menuItems, sizeCounts);

  useEffect(() => {
    const interval = setInterval(() => {
      setMessageIndex((prev) => (prev + 1) % loadingMessages.length);
    }, 2000);
    return () => clearInterval(interval);
  }, [loadingMessages.length]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="flex flex-col items-center justify-center min-h-[400px]"
    >
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
        className="w-20 h-20 mb-8"
      >
        <svg
          className="text-blue-400"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
        >
          <circle className="opacity-25" cx="12" cy="12" r="10" />
          <path
            className="opacity-75"
            d="M12 2C6.477 2 2 6.477 2 12c0 5.523 4.477 10 10 10s10-4.477 10-10c0-5.523-4.477-10-10-10z"
          />
        </svg>
      </motion.div>

      <AnimatePresence mode="wait">
        <motion.div
          key={messageIndex}
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: -20, opacity: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center"
        >
          <h2 className="text-2xl font-bold text-blue-400 mb-2">
            Analyzing lunch line...
          </h2>
          <p className="text-lg text-slate-300">
            {loadingMessages[messageIndex]}
          </p>
        </motion.div>
      </AnimatePresence>
    </motion.div>
  );
}