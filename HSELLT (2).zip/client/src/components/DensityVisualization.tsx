import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";

interface DensityVisualizationProps {
  sizeCounts: Record<string, number>;
  totalCount: number;
}

export default function DensityVisualization({ sizeCounts, totalCount }: DensityVisualizationProps) {
  // Calculate density percentages
  const densityMap = Object.entries(sizeCounts).map(([size, count]) => ({
    size,
    count,
    percentage: (count / totalCount) * 100,
    // Density weight increases with size (S=1, M=2, L=3, XL=4, XXL=5)
    weight: count * (['S', 'M', 'L', 'XL', 'XXL'].indexOf(size) + 1)
  }));

  // Calculate total weight to normalize density
  const totalWeight = densityMap.reduce((sum, { weight }) => sum + weight, 0);

  return (
    <Card className="p-4 bg-slate-800/50 border-slate-700">
      <h3 className="text-lg font-semibold text-slate-200 mb-3">
        Crowd Density Distribution
      </h3>
      <div className="space-y-3">
        {densityMap.map(({ size, count, percentage, weight }) => (
          <div key={size} className="space-y-1">
            <div className="flex justify-between text-sm">
              <span className="text-slate-300">{size}</span>
              <span className="text-slate-400">{count} students</span>
            </div>
            <div className="relative h-2 bg-slate-700 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${(weight / totalWeight) * 100}%` }}
                transition={{ duration: 1, ease: "easeOut" }}
                className={`absolute h-full rounded-full ${
                  size === 'XXL' ? 'bg-red-500' :
                  size === 'XL' ? 'bg-orange-500' :
                  size === 'L' ? 'bg-yellow-500' :
                  size === 'M' ? 'bg-green-500' :
                  'bg-blue-500'
                }`}
              />
            </div>
          </div>
        ))}
      </div>
      <div className="mt-4 text-xs text-slate-400">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-blue-500" />
          <span>Low Density</span>
          <div className="w-3 h-3 rounded-full bg-red-500 ml-4" />
          <span>High Density</span>
        </div>
      </div>
    </Card>
  );
}
